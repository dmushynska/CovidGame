#pragma once

#include "../stdafx.h"
#include "app.h"
#include <windows.h> 
#include <math.h>  
#include <vector>
#include <random>
#include <ctime>
#include <iostream>
#include <fstream>
//----------------------------
//defines
#define COUNT_ENEMY 20
#define COUNT_AMMO 15
#define PLAYER_SIZE_PICTURE 100.0f
#define INTERSECT_ENEMY_AND_AMMO 1166.0f
#define INTERSECT_ENEMY_AND_PLAYER 2332.0f
//-------------------------------
// global obj

bool isDied = false;
int global_x = 0;
int global_y = 0;
//---------------------------------

float crandom(float x) {
	return rand() % (int)x;
}

int random_enemy(float pos_player_m_x_y, float max_x_y) {
	int random = crandom(max_x_y);

	while (random > pos_player_m_x_y - (PLAYER_SIZE_PICTURE * 2) && random < pos_player_m_x_y + (2 * PLAYER_SIZE_PICTURE)) {
		random = crandom(max_x_y);
	}
	return random;
}

bool isIntersection(float first_x, float first_y, float second_x, float second_y, bool IsAmmo) {
	if (IsAmmo == true)
		return((first_x - second_x) * (first_x - second_x)) + ((first_y - second_y) * (first_y - second_y)) <= INTERSECT_ENEMY_AND_AMMO;
	return((first_x - second_x) * (first_x - second_x)) + ((first_y - second_y) * (first_y - second_y)) <= INTERSECT_ENEMY_AND_PLAYER;
}


// get move for one shift
void findpath(float& from_x, float& from_y, float to_x, float to_y) {
	float del_x = from_x - to_x;
	float del_y = from_y - to_y;
	float length = std::sqrt(del_x * del_x + del_y * del_y);
	from_x = del_x / length;
	from_y = del_y / length;
}
