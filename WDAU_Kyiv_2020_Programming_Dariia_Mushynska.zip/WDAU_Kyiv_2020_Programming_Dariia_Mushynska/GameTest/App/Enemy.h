#pragma once
#include "Ammo.h"
#include <chrono>
#include <thread>


class Enemies {
	std::vector<CSimpleSprite*> enemies;
public:

	~Enemies();

	void Init();

	void Update(float deltaTime, float x_player, float y_player);

	void Draw();

	std::vector<CSimpleSprite*> GetData();
	
	void CHeckIfEnemyOrPlayerIsKilled(std::vector<CSimpleSprite*> enemies, Ammo &ammo, Ammo& superAmmo, float player_x, float player_y);

	void NewGame();
};


Enemies::~Enemies() {
	for (int i = 0; i < enemies.size(); i++) {
		delete enemies[i];
	}
}

void Enemies::Init() {
	for (int i = 0; i < COUNT_ENEMY; i++) {
		CSimpleSprite* testSprite2 = App::CreateSprite(".\\TestData\\enemy.bmp", 1, 1);
		testSprite2->SetPosition(random_enemy(500, 1500), random_enemy(400, 1000));
		testSprite2->SetFrame(0);
		testSprite2->SetScale(0.1f);
		enemies.push_back(testSprite2);
	}
}

void Enemies::Update(float deltaTime, float x_player, float y_player) {
	float x_enemy = 0;
	float y_enemy = 0;
	float speed = 1;
	float move_x;
	float move_y;

	for (int i = 0; i < COUNT_ENEMY; i++) {
		(i % 2 == 0) ? speed = 2 : speed = 1;
		enemies[i]->Update(deltaTime);
		enemies[i]->GetPosition(x_enemy, y_enemy);
		move_x = x_enemy;
		move_y = y_enemy;
		findpath(move_x, move_y, x_player, y_player);
		enemies[i]->SetPosition(x_enemy - (speed * move_x), y_enemy - (move_y * speed));
	}
}

void Enemies::Draw() {
	for (int i = 0; i < COUNT_ENEMY; i++) {
		enemies[i]->Draw();
	}
}

std::vector<CSimpleSprite*> Enemies::GetData() {
	return enemies;
}

void Enemies::CHeckIfEnemyOrPlayerIsKilled(std::vector<CSimpleSprite*> enemies, Ammo& ammo, Ammo& superAmmo, float player_x, float player_y) {
	float enemy_x = 0;
	float enemy_y = 0;
	float ammo_x = 0;
	float ammo_y = 0;

	for (auto enemy : enemies) {
		enemy->GetPosition(enemy_x, enemy_y);
		for (int i = ammo.GetShots() - 1; i > -1; i--) {
			ammo.GetData()[i].GetPosition(ammo_x, ammo_y);
			if (isIntersection(enemy_x, enemy_y, ammo_x, ammo_y, true) == true) {
				ammo.DestroyBullet(i);
				enemy->SetPosition(random_enemy(500, 1500), random_enemy(400, 1000));
			}
		}
		for (int i = superAmmo.GetShots() - 1; i > -1; --i) {
			superAmmo.GetData()[i].GetPosition(ammo_x, ammo_y);
			if (isIntersection(enemy_x, enemy_y, ammo_x, ammo_y, true) == true) {
				superAmmo.DestroyBullet(i);
				enemy->SetPosition(random_enemy(500, 1500), random_enemy(400, 1000));
			}
		}
		if (isIntersection(enemy_x, enemy_y, player_x, player_y, false) == true) {
			isDied = true;
			return;
			enemy->SetPosition(random_enemy(500, 1500), random_enemy(400, 1000));
		}
	}
}



void Enemies::NewGame() {
	for (int i = 0; i < COUNT_ENEMY; i++) {
		enemies[i]->SetPosition(random_enemy(500, 1500), random_enemy(400, 1000));
	}
}