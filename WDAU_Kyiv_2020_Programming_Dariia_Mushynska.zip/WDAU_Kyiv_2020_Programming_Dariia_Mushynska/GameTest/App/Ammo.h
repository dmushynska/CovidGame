#pragma once
#include "Algorithm.h"

class Bullet {
	CSimpleSprite* bullet;
	// target
	float target_x = 0;
	float target_y = 0;
	// move bullet for one shift
	float move_x = 0;
	float move_y = 0;

public:
	Bullet() = default;

	void Init(const char* path);

	bool checkIfFree();

	void OutOfRange();

	void SetTarget(float x, float y);

	void SetPosition(float x, float y);

	void GetPosition(float& x, float& y);

	void operator=(const Bullet& old);
	
	void Update(float deltaTime);

	void Draw();

	CSimpleSprite* GetSprite();

	~Bullet();

};

class Ammo {
public:

	Ammo();

	~Ammo() = default;

	void Init(const char* path);

	void Newshot(float x_mouse, float y_mouse, float x_player, float y_player);

	void DestroyBullet(int pos);

	void Update(float deltaTime);

	void Render();

	int GetShots();

	std::vector<Bullet>& GetData();

	void NewGame();

	void NewShots(float x_player, float y_player);

private:
	std::vector<Bullet> ammo;
	int shots = 0;
};


void Bullet::Init(const char *path) {
	bullet = App::CreateSprite(path, 1, 1);
	bullet->SetPosition(-200, -200);
	bullet->SetFrame(0);
	bullet->SetScale(0.05f);
}

bool Bullet::checkIfFree() {
	float x;
	float y;

	bullet->GetPosition(x, y);
	if (x > 1000 || x < -100 || y > 800 || y < 0)
		return true;
	return false;
}

void Bullet::OutOfRange() {
	target_x = 0;
	target_y = 0;
	move_x = 0;
	move_y = 0;
	bullet->SetPosition(-100, -100);
}

void Bullet::SetTarget(float x, float y) {
	target_x = x;
	target_y = y;
	bullet->GetPosition(move_x, move_y);
	findpath(move_x, move_y, target_x, target_y);
}

void Bullet::SetPosition(float x, float y) {
	bullet->SetPosition(x, y);
}

void Bullet::operator=(const Bullet& old) {
	float pos_x = 0;
	float pos_y = 0;
	target_x = old.target_x;
	target_y = old.target_y;
	move_x = old.move_x;
	move_y = old.move_y;
	old.bullet->GetPosition(pos_x, pos_y);
	bullet->SetPosition(pos_x, pos_y);
}

void Bullet::Update(float deltaTime) {
	float pos_x = 0;
	float pos_y = 0;
	bullet->Update(deltaTime);
	bullet->GetPosition(pos_x, pos_y);
	bullet->SetPosition(pos_x - (move_x * 4), pos_y - (move_y * 4));
}

void Bullet::Draw() {
	bullet->Draw();
}


void Bullet::GetPosition(float& x, float& y) {
	bullet->GetPosition(x, y);
}


CSimpleSprite* Bullet::GetSprite() {
	return bullet;
}

Bullet::~Bullet() {
	delete bullet;
}

//////--------------------------------------------


Ammo::Ammo() {
	for (int i = 0; i < COUNT_AMMO; i++) {
		ammo.push_back(Bullet());
	}
}

void Ammo::Init(const char* path) {
	for (int i = 0; i < COUNT_AMMO; i++) {
		ammo[i].Init(path);
	}
}

void Ammo::Newshot(float x_mouse, float y_mouse, float x_player, float y_player) {
	if (shots < COUNT_AMMO) {
		ammo[shots].SetPosition(x_player, y_player);
		ammo[shots].SetTarget(x_mouse, y_mouse);
		shots++;
		App::PlaySound(".\\TestData\\Test.wav");
	}
}

void Ammo::DestroyBullet(int pos) {
	ammo[pos] = ammo[--shots];
	ammo[shots].OutOfRange();
}

void Ammo::Update(float deltaTime) {
	for (int i = 0; i < COUNT_AMMO; i++) {
		ammo[i].Update(deltaTime);
		if (ammo[i].checkIfFree() && i < shots)
			DestroyBullet(i);
	}
}

void Ammo::Render() {
	for (int i = 0; i < COUNT_AMMO; i++) {
		ammo[i].Draw();
	}
}

int Ammo::GetShots() {
	return shots;
}

std::vector<Bullet>& Ammo::GetData() {
	return ammo;
}

void Ammo::NewGame() {
	for (int i = 0; i < COUNT_AMMO; i++) {
		ammo[i].OutOfRange();
	}
	shots = 0;
}
#define M_PI 3.14
void Ammo::NewShots(float x_player, float y_player) {

	float x = x_player;
	float y = y_player;
	float R = 200;
	double angle = 0;
	shots = 0;

	for (int i = 0; i < COUNT_AMMO; i++)
	{
		x = x_player + R * cos(angle * M_PI / 180);
		y = y_player + R * sin(angle * M_PI / 180);
		angle = angle + 360 / (double)COUNT_AMMO;
		Newshot(x, y, x_player, y_player);
	}
}
