//------------------------------------------------------------------------
// GameTest.cpp
//------------------------------------------------------------------------
#include "stdafx.h"
//------------------------------------------------------------------------
#include <windows.h> 
#include <math.h>  
#include <vector>
#include <random>
#include <ctime>
#include <iostream>
#include <fstream>
//------------------------------------------------------------------------
#include "app\app.h"
#include  "app\Enemy.h"
//------------------------------------------------------------------------
//------------------------------------------------------------------------
// Eample data....
//------------------------------------------------------------------------
CSimpleSprite *map;
CSimpleSprite *player;
CSimpleSprite *aim;
Ammo ammo;
Ammo superAmmo;
Enemies enemies;
auto time_start = std::chrono::high_resolution_clock::now();
auto time_lst_recharge = std::chrono::high_resolution_clock::now();
//------------------------------------------------------------------------



//------------------------------------------------------------------------
// Called before first update. Do any initial setup here.
//------------------------------------------------------------------------
void Init()
{
	//------------------------------------------------------------------------
	// Example Sprite Code....
	srand(unsigned int(time(0)));

	// init player
	player = App::CreateSprite(".\\TestData\\smile.bmp", 1, 1);
	player->SetFrame(0);
	player->SetPosition(500.0f, 400.0f);
	player->SetScale(0.3f);

	// init enemies
	enemies.Init();

	//init ammo
	ammo.Init(".\\TestData\\1.bmp");
	superAmmo.Init(".\\TestData\\2.bmp");

	//init aim
	aim = App::CreateSprite(".\\TestData\\reticle.bmp", 1, 1);
	aim->SetFrame(0);
	aim->SetPosition(100.0f, 100.0f);
	aim->SetScale(4.0f);

	//init map
	map = App::CreateSprite(".\\TestData\\map.bmp", 1, 1);
	map->SetFrame(0);
	map->SetPosition(1000.0f, 400.0f);
	map->SetScale(4.0f);

	//------------------------------------------------------------------------
}

//------------------------------------------------------------------------
// Update your simulation here. deltaTime is the elapsed time since the last update in ms.
// This will be called at no greater frequency than the value of APP_MAX_FRAME_RATE
//------------------------------------------------------------------------
void Update(float deltaTime)
{
	//------------------------------------------------------------------------
	// Example Sprite Code....
	if (App::GetController().GetLeftThumbStickX() > 0.5f)
	{
		float x, y;
		player->GetPosition(x, y);
		x += 1.0f;
		if (x < 985)
			player->SetPosition(x, y);
		if (global_x + 400 > 80)
			global_x--;
	}
	if (App::GetController().GetLeftThumbStickX() < -0.5f)
	{
		float x, y;
		player->GetPosition(x, y);
		x -= 1.0f;
		if (x > 40) {
			player->SetPosition(x, y);
		}
		if (global_x + 400 < 940)
			global_x++;
	}
	if (App::GetController().GetLeftThumbStickY() < -0.5f)
	{
		float x, y;
		player->GetPosition(x, y);
		y += 1.0f;
		if (y < 730) {
			player->SetPosition(x, y);
		}
		if (global_y + 400 > 300)
			global_y--;
	}
	if (App::GetController().GetLeftThumbStickY() > 0.5f)
	{
		float x, y;
		player->GetPosition(x, y);
		y -= 1.0f;
		if (y > 20)
			player->SetPosition(x, y);
		if (global_y + 400 < 480)
			global_y++;
	}
	player->Update(deltaTime);
	aim->Update(deltaTime);
	float x_player = 0;
	float y_player = 0;
	float x_aim = 0;
	float y_aim = 0;
	float x_mouse = 0;
	float y_mouse = 0;

	player->GetPosition(x_player, y_player);
	x_aim = x_player;
	y_aim = y_player;
	aim->GetPosition(x_aim, y_aim);
	App::GetMousePos(x_mouse, y_mouse);

	aim->SetPosition(x_mouse, y_mouse);
	if (App::IsKeyPressed(0x01) && std::chrono::high_resolution_clock::now() - time_start > std::chrono::milliseconds(200)) {
		ammo.Newshot(x_mouse, y_mouse, x_player, y_player);
		time_start = std::chrono::high_resolution_clock::now();
	}
	if (App::IsKeyPressed(0x02) && std::chrono::high_resolution_clock::now() - time_lst_recharge > std::chrono::seconds(5)) {
		superAmmo.NewShots(x_player, y_player);
		time_lst_recharge = std::chrono::high_resolution_clock::now();
	}
	superAmmo.Update(deltaTime);
	ammo.Update(deltaTime);
	enemies.Update(deltaTime, x_player, y_player);
	enemies.CHeckIfEnemyOrPlayerIsKilled(enemies.GetData(), ammo, superAmmo, x_player, y_player);
	map->SetPosition(400 + global_x, 400 + global_y);
}

//------------------------------------------------------------------------
// Add your display calls here (DrawLine,Print, DrawSprite.) 
// See App.h 
//------------------------------------------------------------------------
void Render()
{	
	//------------------------------------------------------------------------
	// Example Sprite Code....
	map->Draw();
	player->Draw();
	aim->Draw();
	ammo.Render();
	superAmmo.Render();
	enemies.Draw();
	
//------------------------------------------------------------------------
	if (isDied == true) {
		isDied = false;
		//using namespace std::chrono_literals;
		//auto start = std::chrono::high_resolution_clock::now();
		//std::this_thread::sleep_for(1s);
		//auto end = std::chrono::high_resolution_clock::now();
		//std::chrono::duration<double, std::milli> elapsed = end - start;
		for (int i = 0; i < 200000000; i++);
		enemies.NewGame();
		ammo.NewGame();
		superAmmo.NewGame();
		Render();
		player->SetPosition(500, 400);
		global_x = 0;
		global_y = 0;
	}
}
//------------------------------------------------------------------------
// Add your shutdown code here. Called when the APP_QUIT_KEY is pressed.
// Just before the app exits.
//------------------------------------------------------------------------
void Shutdown()
{	
	//------------------------------------------------------------------------
	// Example Sprite Code....
	delete map;
	delete player;
	delete aim;
	//------------------------------------------------------------------------
}